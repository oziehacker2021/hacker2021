<?php
$raflipedia = 'gorenganfb@gmail.com'; 
?>